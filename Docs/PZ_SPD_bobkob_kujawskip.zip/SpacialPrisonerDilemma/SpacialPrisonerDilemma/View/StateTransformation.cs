namespace SpacialPrisonerDilemma.View
{
    internal delegate int StateTransformation(int parameter);
}